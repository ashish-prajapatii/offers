export class RegisterDto {
  ownerName: string;
  shopName: string;
  logo: string;
  email: string;
  password: string;
  phone: string;
}
